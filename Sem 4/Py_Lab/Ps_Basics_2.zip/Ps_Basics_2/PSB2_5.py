if __name__ == '__main__':
    sentence = input('Enter list : ')
    list_1 = set(sentence.split())
    print(f'length - {len(list_1)}')