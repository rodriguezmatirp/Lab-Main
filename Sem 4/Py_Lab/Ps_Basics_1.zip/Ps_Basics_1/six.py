if __name__ == '__main__' :
    num = int(input())
    sqr_dict = {x : x*x for x in range(1,num +1)}
    print(sqr_dict)