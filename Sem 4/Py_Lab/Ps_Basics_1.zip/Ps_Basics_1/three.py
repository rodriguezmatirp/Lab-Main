if(__name__ == '__main__'):
    num = input()
    sum = 0
    for x in range(1,5):
        sum += int(num*x)
    print(sum)